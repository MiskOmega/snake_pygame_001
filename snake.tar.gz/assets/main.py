import pygame
import asyncio
import sys
import random

# Game constants
SCREEN_WIDTH, SCREEN_HEIGHT = 640, 480
CELL_SIZE = 20
FPS = 10

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

async def wait_for_click():
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False
        await asyncio.sleep(0.05)

def draw_text(surface, text, size, color, pos):
    font = pygame.font.SysFont(None, size)
    text_surface = font.render(text, True, color)
    surface.blit(text_surface, pos)

def game_loop(screen):
    clock = pygame.time.Clock()

    snake = [(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)]
    direction = (CELL_SIZE, 0)

    food = (random.randrange(0, SCREEN_WIDTH, CELL_SIZE), random.randrange(0, SCREEN_HEIGHT, CELL_SIZE))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and direction != (0, CELL_SIZE):
                    direction = (0, -CELL_SIZE)
                elif event.key == pygame.K_DOWN and direction != (0, -CELL_SIZE):
                    direction = (0, CELL_SIZE)
                elif event.key == pygame.K_LEFT and direction != (CELL_SIZE, 0):
                    direction = (-CELL_SIZE, 0)
                elif event.key == pygame.K_RIGHT and direction != (-CELL_SIZE, 0):
                    direction = (CELL_SIZE, 0)

        # Move snake
        new_head = (snake[0][0] + direction[0], snake[0][1] + direction[1])

        # Check boundaries
        if (new_head[0] < 0 or new_head[0] >= SCREEN_WIDTH or
            new_head[1] < 0 or new_head[1] >= SCREEN_HEIGHT or
            new_head in snake):
            # Game over: reset snake
            return

        snake.insert(0, new_head)

        # Check food collision
        if new_head == food:
            food = (random.randrange(0, SCREEN_WIDTH, CELL_SIZE), random.randrange(0, SCREEN_HEIGHT, CELL_SIZE))
        else:
            snake.pop()

        # Drawing
        screen.fill(BLACK)
        for segment in snake:
            pygame.draw.rect(screen, GREEN, (*segment, CELL_SIZE, CELL_SIZE))
        pygame.draw.rect(screen, RED, (*food, CELL_SIZE, CELL_SIZE))

        pygame.display.flip()
        clock.tick(FPS)

async def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Snake")

    screen.fill(BLACK)
    draw_text(screen, "Click to Start", 60, WHITE, (180, 200))
    pygame.display.flip()

    await wait_for_click()

    while True:
        game_loop(screen)

asyncio.run(main())
